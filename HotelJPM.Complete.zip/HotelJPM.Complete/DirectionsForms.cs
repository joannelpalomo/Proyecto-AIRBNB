﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelJPM
{
    public partial class DirectionsForms : Form
    {
        public DirectionsForms()
        {
            InitializeComponent();
        }

        private void _btnDirections_Click(object sender, EventArgs e)
        {
            // Esto hace que las direcciones aparezcan al momento de precionar el boton
            _labelDirections.Visible = true;
        }

        private void _bntExit_Click(object sender, EventArgs e)
        {
            // Esto hace que al precionar el boton cierre el programa
            this.Close();
        }

        private void _picture_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Existe el boton");
        }
    }
}
