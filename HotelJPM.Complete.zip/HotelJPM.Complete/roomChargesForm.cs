﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelJPM
{
    public partial class roomChargesForm : Form
    {
        public roomChargesForm()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // Variables utilizadas
            double RoomCharges, NightCharges, Additional, Subtotal, Total, Telephone, Misc, Service, Taxlbl;
            int Nights;
            
            // Conversion a numeros

            Nights = int.Parse(txtNights.Text);
            NightCharges = double.Parse(txtCharges.Text);
            Service = double.Parse(txtService.Text);
            Misc = double.Parse(txtMisc.Text);
            Telephone = double.Parse(txtPhone.Text);

            // Proceso Matematico
            RoomCharges = NightCharges * Nights;
            Additional = Service + Misc + Telephone;
            Subtotal = RoomCharges + Additional;
            Taxlbl = Subtotal * 0.115;
            Total = Subtotal + Taxlbl;

            // Output
            lblCharges.Text = "$" + RoomCharges.ToString("n2");
            lblAdditional.Text = "$" + Additional.ToString("n2");
            lblSubtotal.Text = "$" + Subtotal.ToString("n2");
            lblTax.Text = "$" + Taxlbl.ToString("n2");
            lblTotal.Text = "$" + Total.ToString("n2");
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void roomChargesForm_Load(object sender, EventArgs e)
        {
            // Variables para la fecha
            string Fecha = DateTime.Now.ToString("dd/MM/yyyy");
            string Hora = DateTime.Now.ToShortTimeString().ToString();

            // Display la fecha
            lblDate.Text = Fecha;
            lblTime.Text = Hora;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtNights.Focus();
            lblCharges.Text = "";
            lblAdditional.Text = "";
            lblSubtotal.Text = "";
            lblTax.Text = "";
            lblTotal.Text = "";
            txtCharges.Text = "";
            txtNights.Text = "";
            txtMisc.Text = "";
            txtPhone.Text = "";
            txtService.Text = "";
        }
    }
}
