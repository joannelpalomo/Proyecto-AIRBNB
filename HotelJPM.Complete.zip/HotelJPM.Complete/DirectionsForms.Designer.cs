﻿namespace HotelJPM
{
    partial class DirectionsForms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DirectionsForms));
            this._labelTitle = new System.Windows.Forms.Label();
            this._picture = new System.Windows.Forms.PictureBox();
            this._labelDirections = new System.Windows.Forms.Label();
            this._btnDirections = new System.Windows.Forms.Button();
            this._bntExit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this._picture)).BeginInit();
            this.SuspendLayout();
            // 
            // _labelTitle
            // 
            this._labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._labelTitle.Location = new System.Drawing.Point(220, 9);
            this._labelTitle.Name = "_labelTitle";
            this._labelTitle.Size = new System.Drawing.Size(487, 38);
            this._labelTitle.TabIndex = 0;
            this._labelTitle.Text = "DIRECTIONS TO THE HIGHLANDER HOTEL\r\n";
            this._labelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _picture
            // 
            this._picture.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._picture.Image = ((System.Drawing.Image)(resources.GetObject("_picture.Image")));
            this._picture.Location = new System.Drawing.Point(128, 50);
            this._picture.Name = "_picture";
            this._picture.Size = new System.Drawing.Size(669, 341);
            this._picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this._picture.TabIndex = 1;
            this._picture.TabStop = false;
            this._picture.Click += new System.EventHandler(this._picture_Click);
            // 
            // _labelDirections
            // 
            this._labelDirections.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._labelDirections.Location = new System.Drawing.Point(182, 394);
            this._labelDirections.Name = "_labelDirections";
            this._labelDirections.Size = new System.Drawing.Size(564, 60);
            this._labelDirections.TabIndex = 0;
            this._labelDirections.Text = "Traveling on I-89, take Exit 125 South, The hotel is on the left.\r\n\r\nTraveling on" +
    " Highway 101 North, the hotel is on the right, just before the I-89 intersection" +
    ".";
            this._labelDirections.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this._labelDirections.Visible = false;
            // 
            // _btnDirections
            // 
            this._btnDirections.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._btnDirections.Location = new System.Drawing.Point(225, 457);
            this._btnDirections.Name = "_btnDirections";
            this._btnDirections.Size = new System.Drawing.Size(98, 55);
            this._btnDirections.TabIndex = 2;
            this._btnDirections.Text = "Directions";
            this._btnDirections.UseVisualStyleBackColor = true;
            this._btnDirections.Click += new System.EventHandler(this._btnDirections_Click);
            // 
            // _bntExit
            // 
            this._bntExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._bntExit.Location = new System.Drawing.Point(609, 457);
            this._bntExit.Name = "_bntExit";
            this._bntExit.Size = new System.Drawing.Size(98, 55);
            this._bntExit.TabIndex = 2;
            this._bntExit.Text = "Exit";
            this._bntExit.UseVisualStyleBackColor = true;
            this._bntExit.Click += new System.EventHandler(this._bntExit_Click);
            // 
            // DirectionsForms
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(936, 547);
            this.Controls.Add(this._bntExit);
            this.Controls.Add(this._btnDirections);
            this.Controls.Add(this._picture);
            this.Controls.Add(this._labelDirections);
            this.Controls.Add(this._labelTitle);
            this.Name = "DirectionsForms";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HOTEL_APP_DIRECTIONS";
            this.TopMost = true;
            ((System.ComponentModel.ISupportInitialize)(this._picture)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label _labelTitle;
        private System.Windows.Forms.PictureBox _picture;
        private System.Windows.Forms.Label _labelDirections;
        private System.Windows.Forms.Button _btnDirections;
        private System.Windows.Forms.Button _bntExit;
    }
}

