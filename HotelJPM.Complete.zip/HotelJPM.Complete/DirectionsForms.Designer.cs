﻿namespace HotelJPM
{
    partial class DirectionsForms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DirectionsForms));
            this._labelTitle = new System.Windows.Forms.Label();
            this._picture = new System.Windows.Forms.PictureBox();
            this._labelDirections = new System.Windows.Forms.Label();
            this._btnDirections = new System.Windows.Forms.Button();
            this._bntExit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this._picture)).BeginInit();
            this.SuspendLayout();
            // 
            // _labelTitle
            // 
            this._labelTitle.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._labelTitle.Location = new System.Drawing.Point(252, 31);
            this._labelTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this._labelTitle.Name = "_labelTitle";
            this._labelTitle.Size = new System.Drawing.Size(811, 56);
            this._labelTitle.TabIndex = 0;
            this._labelTitle.Text = "DIRECTIONS TO THE AIRBNB\r\n\r\n";
            this._labelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _picture
            // 
            this._picture.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._picture.Image = ((System.Drawing.Image)(resources.GetObject("_picture.Image")));
            this._picture.Location = new System.Drawing.Point(293, 74);
            this._picture.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this._picture.Name = "_picture";
            this._picture.Size = new System.Drawing.Size(725, 382);
            this._picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this._picture.TabIndex = 1;
            this._picture.TabStop = false;
            this._picture.Click += new System.EventHandler(this._picture_Click);
            // 
            // _labelDirections
            // 
            this._labelDirections.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._labelDirections.Location = new System.Drawing.Point(185, 457);
            this._labelDirections.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this._labelDirections.Name = "_labelDirections";
            this._labelDirections.Size = new System.Drawing.Size(940, 88);
            this._labelDirections.TabIndex = 0;
            this._labelDirections.Text = "El Escambrón Beach,\r\n1479 Ashford Avenue, San Juan, PR (Ocean View & Direct Acces" +
    "s to Condado Beach)";
            this._labelDirections.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this._labelDirections.Visible = false;
            // 
            // _btnDirections
            // 
            this._btnDirections.BackColor = System.Drawing.Color.LightBlue;
            this._btnDirections.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._btnDirections.Location = new System.Drawing.Point(312, 550);
            this._btnDirections.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this._btnDirections.Name = "_btnDirections";
            this._btnDirections.Size = new System.Drawing.Size(163, 81);
            this._btnDirections.TabIndex = 2;
            this._btnDirections.Text = "Directions";
            this._btnDirections.UseVisualStyleBackColor = false;
            this._btnDirections.Click += new System.EventHandler(this._btnDirections_Click);
            // 
            // _bntExit
            // 
            this._bntExit.BackColor = System.Drawing.Color.LightBlue;
            this._bntExit.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._bntExit.Location = new System.Drawing.Point(833, 550);
            this._bntExit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this._bntExit.Name = "_bntExit";
            this._bntExit.Size = new System.Drawing.Size(163, 81);
            this._bntExit.TabIndex = 2;
            this._bntExit.Text = "Exit";
            this._bntExit.UseVisualStyleBackColor = false;
            this._bntExit.Click += new System.EventHandler(this._bntExit_Click);
            // 
            // DirectionsForms
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Moccasin;
            this.ClientSize = new System.Drawing.Size(1202, 647);
            this.Controls.Add(this._bntExit);
            this.Controls.Add(this._btnDirections);
            this.Controls.Add(this._picture);
            this.Controls.Add(this._labelDirections);
            this.Controls.Add(this._labelTitle);
            this.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "DirectionsForms";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HOTEL_APP_DIRECTIONS";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.DirectionsForms_Load);
            ((System.ComponentModel.ISupportInitialize)(this._picture)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label _labelTitle;
        private System.Windows.Forms.PictureBox _picture;
        private System.Windows.Forms.Label _labelDirections;
        private System.Windows.Forms.Button _btnDirections;
        private System.Windows.Forms.Button _bntExit;
    }
}

